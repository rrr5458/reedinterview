export const typeOptions: string[] = [
  "Mesla Supercharger",
  "QAE Combo CCS",
  "SHAdeMO",
  "T1772 (T-plug)",
];